import java.util.Arrays;
public class Main {
    public static void main(String[] args) {
        Integer[] intVector = { 101, 99, 12, 19, 21, 111, 345, 25, 77, 81 };
        Integer[] resultInt = Utils.ordena(intVector);
        System.out.println(Arrays.toString(resultInt));

       // Integer[] floatVector = { 19.1, 456.6, 23.45, 12.34, 11.11, 354.55, 78.45, 28.33, 45.99, 108.88 };
       // Integer[] resultFloat = Utils.ordena(floatVector);
       // System.out.println(Arrays.toString(resultFloat));
    }
}


